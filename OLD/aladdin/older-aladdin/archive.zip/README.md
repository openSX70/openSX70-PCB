# openSX70-PCB
EagleCAD design files for the main PCB of the openSX70 project
